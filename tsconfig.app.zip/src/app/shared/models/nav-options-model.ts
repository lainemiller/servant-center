export interface NavOptions {
  name: string;
  url: string;
  color: string;
  icon: string;
}