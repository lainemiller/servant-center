import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CaseWorkerProfileComponent } from './case-worker-profile.component';

describe('CaseWorkerProfileComponent', () => {
  let component: CaseWorkerProfileComponent;
  let fixture: ComponentFixture<CaseWorkerProfileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CaseWorkerProfileComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CaseWorkerProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
