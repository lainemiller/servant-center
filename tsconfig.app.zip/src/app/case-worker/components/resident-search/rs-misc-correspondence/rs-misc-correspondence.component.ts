import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rs-misc-correspondence',
  templateUrl: './rs-misc-correspondence.component.html',
  styleUrls: ['./rs-misc-correspondence.component.scss']
})
export class RsMiscCorrespondenceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
