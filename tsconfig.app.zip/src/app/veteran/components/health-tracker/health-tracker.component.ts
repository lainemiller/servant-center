import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-health-tracker',
  templateUrl: './health-tracker.component.html',
  styleUrls: ['./health-tracker.component.scss']
})
export class HealthTrackerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
