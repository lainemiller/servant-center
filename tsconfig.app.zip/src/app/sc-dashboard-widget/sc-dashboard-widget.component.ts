import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sc-dashboard-widget',
  templateUrl: './sc-dashboard-widget.component.html',
  styleUrls: ['./sc-dashboard-widget.component.scss']
})
export class ScDashboardWidgetComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
